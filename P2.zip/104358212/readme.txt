104358212
Wendi Liu
wendiliu1990@gmail.com

804363366
Xinlei Wang
wangxl@ucla.edu

Wendi Liu is responsible for coding Part A, B and C.
Xinlei Wang is responsible for coding Part D and testing Part A, B, C and D.